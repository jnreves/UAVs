%% Adding ARDrone library to the path
addpath ../lib/ ; 

%%
ARDroneReplay_V2 ; 