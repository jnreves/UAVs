#include "__cf_ARDroneHoverSim.h"
#ifndef RTW_HEADER_ARDroneHoverSim_capi_h
#define RTW_HEADER_ARDroneHoverSim_capi_h
#include "ARDroneHoverSim.h"
extern void ARDroneHoverSim_InitializeDataMapInfo ( void ) ;
#endif
