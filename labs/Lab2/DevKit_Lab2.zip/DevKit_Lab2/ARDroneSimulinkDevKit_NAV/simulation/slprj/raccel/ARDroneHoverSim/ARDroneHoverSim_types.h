#include "__cf_ARDroneHoverSim.h"
#ifndef RTW_HEADER_ARDroneHoverSim_types_h_
#define RTW_HEADER_ARDroneHoverSim_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_Ka1LQkcaTuqbPFRwNN4XNE_
#define DEFINED_TYPEDEF_FOR_struct_Ka1LQkcaTuqbPFRwNN4XNE_
typedef struct { real_T Ts ; } struct_Ka1LQkcaTuqbPFRwNN4XNE ;
#endif
typedef struct P_ P ;
#endif
