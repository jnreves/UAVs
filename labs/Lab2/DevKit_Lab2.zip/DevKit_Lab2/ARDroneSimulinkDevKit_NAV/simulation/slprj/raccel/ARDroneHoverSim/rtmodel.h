#include "__cf_ARDroneHoverSim.h"
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "ARDroneHoverSim.h"
#define GRTINTERFACE 1
#endif
